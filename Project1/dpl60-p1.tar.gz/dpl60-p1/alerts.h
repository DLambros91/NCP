#ifndef ALERT_H

#define ALERT_H



/*

 *	alerts.h

 */





void warning(char * msg);



void error(char * msg);



void success(char * msg);



void genwarn();



void generr();



void gensucc();











#endif
